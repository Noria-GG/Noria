# Noria — GT7スポーツモード上達アドバイスチャット (レイヤー1 MVP)

## これは何か
GT7のスポーツモードに関する相談ができるチャットボットの最小構成です。
Express(サーバー) + Anthropic API(頭脳) + シンプルなHTMLチャット画面、という3点構成になっています。

## フォルダ構成
```
noria/
├── package.json       # 依存パッケージの定義
├── .env.example        # 環境変数のサンプル(APIキーなど)
├── server.js           # サーバー本体。Anthropic APIを呼び出すエンドポイントを持つ
└── public/
    └── index.html       # チャット画面(HTML/CSS/JSを1ファイルにまとめてあります)
```

## セットアップ手順(Claude Codeでの作業を想定)

1. **Node.jsをインストール**(未導入の場合)
   https://nodejs.org/ からLTS版を入れてください。

2. **依存パッケージをインストール**
   ```
   npm install
   ```

3. **APIキーを設定**
   `.env.example` を `.env` にコピーし、`ANTHROPIC_API_KEY` に自分のAPIキーを入力してください。
   ```
   cp .env.example .env
   ```

4. **サーバーを起動**
   ```
   npm start
   ```

5. **ブラウザで開く**
   http://localhost:3000 にアクセス

## 今後拡張する場所(レイヤー3=SNS/コミュニティ連携を見据えて)

- `server.js` 内の `NORIA_SYSTEM_PROMPT` は、Noriaの「人格・専門知識」を定義している部分です。
  将来的にDiscord Botを追加する場合も、このプロンプトと `/api/chat` のロジックをそのまま流用できるように、
  あえてWebのUI部分(`public/`)とロジック部分(`server.js`)を分離しています。
- ゲームをGT7以外に広げる場合は、`NORIA_SYSTEM_PROMPT` をゲームごとに切り替えられるよう、
  別ファイルに切り出すと管理しやすくなります。

## 今のところやっていないこと(意図的に後回し)

- データ分析・成績トラッキング機能(レイヤー2)
- Discord Bot連携(レイヤー3の本格版。まずは公式サーバー設立のみで様子見)
- ユーザーごとの会話履歴の永続化(今は画面をリロードすると履歴が消えます)
